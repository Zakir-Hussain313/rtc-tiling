import Mainbutton from "@/Components/Mainbutton";
import '../../styles/Projects/ProjectsCTA.css'
import FadeIn from "@/Components/FadeIn";

export default function ProjectsCTA() {
    return (
        <div className="projectsCTA-wrapper">
            <section className="projectsCTA-main-section">
                <FadeIn>
                    <h1>let&apos;s work together to transform your space</h1>
                </FadeIn>
                <FadeIn delay={150}>
                    <p>Reach out today, and let&apos;s discuss project.</p>
                </FadeIn>
                <FadeIn className="projectsCTA-button" delay={300}>
                    <Mainbutton
                        data="Call Now"
                        href="tel:0480205289"
                        fontSize="clamp(15px, 2vw, 20px)"
                        padding="5px 5px 5px 20px"
                        arrowSize="clamp(38px, 4vw, 50px)"
                        backgroundColor="#fff"
                        textColor="#111"
                        border="2px solid #444"
                        borderOnHover="2px solid transparent"
                        hoverBubbleColor="#4d3d2d"
                        hoverTextColor="white"
                    />
                </FadeIn>
            </section>
        </div>
    )
}