import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IProject extends Document {
    title: string;
    description: string;
    images: string[];
    imagePublicIds: string[];
    type: string;
    location: string;
    size: string;
    designStyle: string;
    client: string;
    date: string;
    slug: string;
    order: number;
    featured: boolean;
    createdAt: Date;
    updatedAt: Date;
}

const ProjectSchema = new Schema<IProject>(
    {
        title:          { type: String, required: true, trim: true },
        description:    { type: String, default: '', trim: true },
        images:         { type: [String], default: [] },
        imagePublicIds: { type: [String], default: [] },
        type:           { type: String, default: '', trim: true },
        location:       { type: String, default: '', trim: true },
        size:           { type: String, default: '', trim: true },
        designStyle:    { type: String, default: '', trim: true },
        client:         { type: String, default: '', trim: true },
        date:           { type: String, default: '', trim: true },
        slug:           { type: String, required: true, unique: true, trim: true },
        order:          { type: Number, default: 0 },
        featured:       { type: Boolean, default: false },
    },
    { timestamps: true }
);

const Project: Model<IProject> =
    mongoose.models.Project || mongoose.model<IProject>('Project', ProjectSchema);

export default Project;